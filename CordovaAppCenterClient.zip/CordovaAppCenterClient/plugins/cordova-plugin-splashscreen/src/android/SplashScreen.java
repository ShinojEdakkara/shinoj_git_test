/*
 * IBM Confidential OCO Source Materials
 *
 * 5725-I43 Copyright IBM Corp. 2006, 2013
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 *
*/

package com.ibm.appcenter.plugin;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

public class SplashScreen extends CordovaPlugin {
	private final static String ACTION_SHOW = "show";
	private final static String ACTION_HIDE = "hide";

	private static SplashScreen instance = new SplashScreen();

	//the name of the .png file that is located in the res/drawable folder
	private static final String splashScreenFileName = "splash";

	private Dialog splashDialog;

	private ActivityLifecycleCallbacks activityListener;
	private String activityClassName;

	public static SplashScreen getInstance() {
		return instance;
	}

	public void show(Activity activity){

		//getIdentifier returns 0 if no resource file was found
		int splashResourceID = activity.getResources().getIdentifier(splashScreenFileName , "drawable", activity.getPackageName());

		if (splashDialog != null){
			//logger.debug("Splash screen is already displayed");
		}

		else if (splashResourceID == 0){
		//	logger.warn("Application will not display splash screen because required image is missing. Add "+ splashScreenFileName+ ".png image to res/drawble folder");
		}

		//display a splash screen only if no splash is already displayed and a splash file is exist
		else if (splashResourceID != 0){
		//	logger.debug("Showing Splash Screen");
			displaySplashDialog(activity, splashResourceID);
		}
	}

	public void hide(){

	//	logger.trace("Hiding Splash Screen");

		if (splashDialog!= null){
			splashDialog.dismiss();
			splashDialog = null;
		}
	}

	private void displaySplashDialog(Activity activity, int splashResourceID){
		activityClassName = activity.getClass().getName();
		splashDialog = new Dialog(activity,android.R.style.Theme_Translucent_NoTitleBar);
		splashDialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT);

		LinearLayout linerLayout = new LinearLayout(activity);
        linerLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT, 0.0F));

		ImageView image = new ImageView(activity);

		image.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
		image.setScaleType(ScaleType.FIT_XY);

		image.setBackgroundResource(splashResourceID);

		linerLayout.addView(image);
		splashDialog.setContentView(linerLayout);
		splashDialog.setCancelable(false);
		splashDialog.show();

		//Listen to life-cycle events to auto hide the splash screen in case the underlying activity is destroyed while the splash is showing to prevent leaked window condition and crash (As in Defect #43636)
		if (activityListener == null && Build.VERSION.SDK_INT >= 14 ){
			Application thisApp = (Application)activity.getApplicationContext();
			activityListener = new ActivityListener();
			thisApp.registerActivityLifecycleCallbacks(activityListener);
		}
	}

    class ActivityListener implements ActivityLifecycleCallbacks {

		@Override
		public void onActivityCreated(Activity activity, Bundle bundle) {
		}

		@Override
		public void onActivityDestroyed(Activity activity) {
			// Hide the splash if displayed on the destroyed activity to avoid window leak and crash
			if (activity.getClass().getName().equals(activityClassName)) {
				SplashScreen.getInstance().hide();
			}
		}

		@Override
		public void onActivityPaused(Activity activity) {
		}

		@Override
		public void onActivityResumed(Activity activity) {
		}

		@Override
		public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
		}

		@Override
		public void onActivityStarted(Activity activity) {
		}

		@Override
		public void onActivityStopped(Activity activity) {
		}
	}

	@Override
	public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
		if (ACTION_SHOW.equals(action)) {
			SplashScreen.getInstance().show(this.cordova.getActivity());
			return true;
		} else if (ACTION_HIDE.equals(action)) {
			SplashScreen.getInstance().hide();
			return true;
		} else {
			return false;
		}
	}
}
