/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  ImpRestService.h
//  IBMAppStore
//
//  Created by Stéphane Lizeray on 3/12/12.
//  Copyright (c) 2012 IBM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSURLConnectionWithBlock.h"

typedef void (^IBMCompletionBlock)(NSInteger statusCode);
typedef void (^IBMErrorCompletionBlock)(NSError * errorCode);

@interface IBMAppCenterRestService : NSObject 

@property (strong,nonatomic) NSString* uuid;

+ (IBMAppCenterRestService*)sharedInstance;

- (void) authenticateWithCompletionBlock: (IBMCompletionBlock) completionBlock errorCompletionBlock: (IBMErrorCompletionBlock) completionErrorBlock;

- (BOOL) installApplicationWithBundleId: (NSString *) bundleId
                                version: (NSString *) version
                             installURL: (NSString *) installURL;

- (void) registerAPNStoken : (NSString *)pushDevToken
            completionBlock: (IBMCompletionBlock) completionBlock
       errorCompletionBlock: (IBMErrorCompletionBlock) completionErrorBlock;

@property (nonatomic) NSTimeInterval timeOut;

@end
