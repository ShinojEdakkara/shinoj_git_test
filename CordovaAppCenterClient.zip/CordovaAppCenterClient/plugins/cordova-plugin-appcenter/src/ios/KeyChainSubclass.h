/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */



@interface KeyChain(ForSubclassEyesOnly) 
- (NSDictionary *)searchKeychainCopyMatching;

- (BOOL)createKeychainValue:(NSString *)value;
- (BOOL)updateKeychainValue:(NSString *)value;

// Method to be implemented by the subclass
- (NSMutableDictionary *)searchDictionary;
@end

