/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  IBMAppCenterPlugin.h
//  AppCenterInstallerLib
//
//  Created by Stéphane Lizeray on 9/13/13.
//  Copyright (c) 2013 IBM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Cordova/CDV.h>

@interface IBMAppCenterPlugin : CDVPlugin

- (void)initInfo:(CDVInvokedUrlCommand*)command;

- (void)login:(CDVInvokedUrlCommand*)command;

- (void)getDeviceInfo:(CDVInvokedUrlCommand*)command;

- (void)installApplication:(CDVInvokedUrlCommand*)command;

- (void)getCredentials:(CDVInvokedUrlCommand*)command;

- (void)deleteCredentials:(CDVInvokedUrlCommand*)command;

@end
