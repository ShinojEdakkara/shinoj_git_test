/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  GenericPassword.h
//  AppCenterInstallerLib
//
//  Created by Stéphane Lizeray on 5/23/12.
//  Copyright (c) 2012 IBM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KeyChain.h"

@interface GenericPassword : KeyChain
- (id)initWithAccountName:(NSString *) accountName serviceName: (NSString*) serviceName attributeName:(NSString *) attributeName;
@property (nonatomic,readwrite,strong) NSString * value;
@property (nonatomic,readonly,strong) NSString * serviceName;
@property (nonatomic,readonly,strong) NSString * accountName;
@property (nonatomic,readonly,strong) NSString * attributeName;
@end
