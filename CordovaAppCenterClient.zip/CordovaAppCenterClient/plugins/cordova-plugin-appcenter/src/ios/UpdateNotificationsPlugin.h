/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  UpdateNotificationsPlugin.h
//  AppCenterInstallerLib
//
//  Created by Douliez on 12/02/13.
//  Copyright (c) 2013 IBM. All rights reserved.
//

#import <Cordova/CDVPlugin.h>

@interface UpdateNotificationsPlugin : CDVPlugin <UIApplicationDelegate>

@property (nonatomic,assign) BOOL registered;
// -------------------------------------------------------------
// Asks the plugin to initiate APNS registration
//
// Parameters are
//  Fail callback: a phonegap reference
//  URL: the icon URL
- (void) registerNotifications:(CDVInvokedUrlCommand*)command;
// -------------------------------------------------------------
// Asks the plugin to terminate APNS registration
//
// Parameters are
//  Fail callback: a phonegap reference
//  URL: the icon URL
- (void) unregisterNotifications:(CDVInvokedUrlCommand*)command;

@end
