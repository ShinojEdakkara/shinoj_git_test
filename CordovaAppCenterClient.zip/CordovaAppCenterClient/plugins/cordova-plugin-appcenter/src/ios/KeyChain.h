/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  KeyChain.h
//  AppCenterInstallerLib
//
//  Created by Stéphane Lizeray on 5/23/12.
//  Copyright (c) 2012 IBM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyChain : NSObject
- (void) writeToKeyChain;
- (void)deleteKeychainEntry;
@end


