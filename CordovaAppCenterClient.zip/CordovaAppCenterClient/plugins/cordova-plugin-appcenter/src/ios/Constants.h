/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  Constants.h
//  AppCenterInstallerLib
//
//  Created by Stéphane Lizeray on 9/16/13.
//  Copyright (c) 2013 IBM. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const kAppCenterAccount;
extern NSString * const kAppCenterService;
extern NSString * const kAppCenterUUID;

#define APPCENTER_INTERNET_PWD_TYPE 5


@interface Constants : NSObject

@end
