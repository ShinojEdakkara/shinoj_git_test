/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  InternetPassword.h
//  IBMAppStore
//
//  Created by Stéphane Lizeray on 5/24/12.
//  Copyright (c) 2012 IBM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KeyChain.h"

@interface InternetPassword : KeyChain
- (id) initWithTypeAttribute: (unsigned long long) type;

@property (nonatomic,readonly,strong) NSNumber * typeAttribute;
@property (nonatomic,strong) NSString *server;
@property (nonatomic,strong) NSString *port;
@property (nonatomic,strong) NSString *path;
@property (nonatomic,assign) BOOL https;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *password;

@end
