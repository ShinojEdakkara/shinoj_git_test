/*
 *  Licensed Materials - Property of IBM
 *  5725-I43 (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
 *  US Government Users Restricted Rights - Use, duplication or
 *  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

//
//  NSURLConnectionWithBlock.h
//  IBMAppStore
//
//  Created by Stéphane Lizeray on 2/28/12.
//  Copyright (c) 2012 IBM. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void (^NSURLCompletionBlock)(NSInteger statusCode,NSMutableData *data);
typedef void (^NSURLErrorBlock)(NSError * error);
typedef void (^NSURLAuthenticationChallengeBlock)(NSURLAuthenticationChallenge * authenticationChallenge);

@interface NSURLConnectionWithBlock : NSURLConnection

- (id) initWithRequest:(NSURLRequest *)request; 

@property (nonatomic,copy) NSURLCompletionBlock completionBlock;
@property (nonatomic,copy) NSURLErrorBlock errorBlock;
@property (nonatomic,copy) NSURLAuthenticationChallengeBlock authenticationChallengeBlock;

@end
