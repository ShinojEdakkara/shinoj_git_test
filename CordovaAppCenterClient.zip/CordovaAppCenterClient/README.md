# IBM AppCenter client for Android and IOS

## Introduction/Background

This is a AppCenter Client Application that is based on pure Cordova and doesn’t have any dependency on the MFP client/server API’s. Since this a pure Cordova App, now there is no dependency on MFP Studio (aka 7.1 studio for developing MFP apps). This App still uses DOJO for the UI and is step closer to making it neater.

## Api Versions test with

We have tested with

1. cordova version 6.2.0
2. pinned Cordova Android: ~5.1.1, Cordova iOS: ~4.1.0
3. minimum Android SDK level of 16

Reference: https://cordova.apache.org/news/2016/05/24/tools-release.html

## How do I make it work
Below are few steps that you can follow to make it work.

1. Install Cordova

  ```
  npm install -g cordova@latest
  or
  sudo npm install -g cordova@latest
  ```

2. Install Android SDK and set the ANDROID_HOME
3. Build and run this project

  ```
  cordova build
  or
  cordova build android
  or
  cordova build ios
  ```

Once build is successful, you can find .apk in *platforms/android/build/outputs/apk/android-debug.apk*.

## Customizing AppCenter Client

*Android :*

The project can be imported into Android studio. For this you will have to

1. download the project zip file from the github
2. open the android studio
3. select “Import project (Eclipse ADT, Gradle, etc)”
4. select the android folder from the downloaded project. Eg: “/Users/vinod/Downloads/IBMAppCenterCordova-androidIos/platforms/android”

This might take some time. Please wait... Once this is done you are ready to customize.

Note: Skip the update popup/window for upgrading the gradle version. Ref: grade-wrapper.properties for the version.

*IOS:*

1. download the project zip file from the github
2. click the IBMAppCenterClient.xcodeproj file and the project is opened in Xcode and you are ready to customize
