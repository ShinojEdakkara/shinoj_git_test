
/* JavaScript content from js/idx/mobile/nls/AboutPane.js in folder common */
/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({ root:
//begin v1.x content
({
	labelVersion: "Version",
	labelBuild: "Build",
	logoIBM: "IBM&reg;",
	logoEclipse: "Built on Eclipse"
})
//end v1.x content
});